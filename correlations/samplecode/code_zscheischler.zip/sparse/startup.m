addpath('~/Matlab Programs/tracemethod/')
addpath('~/Matlab Programs/UAI/')
addpath('~/Matlab Programs/UAI/sparse_Kun/lars/')