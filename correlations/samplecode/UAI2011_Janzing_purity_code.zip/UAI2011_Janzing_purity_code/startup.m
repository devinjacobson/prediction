% Copyright (c) 2011  Eleni Sgouritsa
% All rights reserved.  See the file COPYING for license terms.
addpath('data')
addpath('experiments')
addpath('exportfig')
addpath('purity_code')


