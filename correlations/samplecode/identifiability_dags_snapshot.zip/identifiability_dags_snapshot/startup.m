% Copyright (c) 2010-2011  Jonas Peters  [jonas.peters@tuebingen.mpg.de]
% All rights reserved.  See the file COPYING_GPL for license terms. 
%addpath(genpath('gpml-matlab-v3.1-2010-09-27'))
addpath('indtest')
addpath('fit')
addpath('fasthsic')
addpath('util')
addpath('pc')
addpath('kernel_pc')
addpath('find_all_dags')

