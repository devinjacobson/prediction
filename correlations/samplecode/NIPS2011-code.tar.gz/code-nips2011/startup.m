addpath('fasthsic');
addpath('lbfgsb');
addpath('gpml-util');
